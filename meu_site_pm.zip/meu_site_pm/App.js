import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  ScrollView,
  Image,
} from "react-native";


const escola = {
  name: "Sistema Escolar",
  subtitle: "Educação • Conhecimento • Futuro",
  color: "#2563EB",
  image: require("./SIte pm/logo.png"),
};


const disciplinas = [
  "Matemática",
  "Língua Portuguesa",
  "História",
  "Geografia",
  "Ciências",
  "Inglês",
  "Educação Física",
  "Artes",
  "Tecnologia",
];


const turmas = [
  "1º Ano",
  "2º Ano",
  "3º Ano",
  "4º Ano",
  "5º Ano",
  "6º Ano",
  "7º Ano",
  "8º Ano",
  "9º Ano",
];


export default function App() {
  const [screen, setScreen] = useState("home");
  const [profile, setProfile] = useState(null);
  const [selectedMenu, setSelectedMenu] = useState(null);


  const selectProfile = (profileName) => {
    setProfile(profileName);
    setSelectedMenu(null);
    setScreen("dashboard");
  };


  const goBack = () => {
    if (screen === "school") {
      setScreen("home");
    } else if (screen === "login") {
      setScreen("school");
    } else if (screen === "dashboard") {
      setScreen("login");
    } else if (screen === "section") {
      setScreen("dashboard");
    }
  };


  /*
   * TELA INICIAL
   */
  if (screen === "home") {
    return (
      <SafeAreaView style={styles.container}>
        <ScrollView
          contentContainerStyle={styles.homePage}
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.welcomeCard}>
            <View style={styles.logoCircle}>
              <Image
                source={escola.image}
                style={styles.logoImage}
                resizeMode="contain"
              />
            </View>


            <Text style={styles.smallTop}>
              SISTEMA DE GESTÃO ESCOLAR
            </Text>


            <Text style={styles.schoolTitle}>
              {escola.name}
            </Text>


            <Text style={styles.schoolSubtitle}>
              {escola.subtitle}
            </Text>


            <View style={styles.line} />


            <Text style={styles.greeting}>
              Bem-vindo!
            </Text>


            <Text style={styles.welcomeText}>
              É com satisfação que recebemos você em nosso
              ambiente escolar.
            </Text>


            <Text style={styles.welcomeText}>
              Aqui você poderá acompanhar informações acadêmicas,
              turmas, disciplinas, avaliações e muito mais.
            </Text>


            <Text style={styles.welcomeText}>
              Nosso objetivo é facilitar o acesso às informações
              e tornar a experiência escolar mais organizada,
              prática e eficiente.
            </Text>


            <View style={styles.separator} />


            <Text style={styles.invitation}>
              SEU FUTURO COMEÇA AQUI
            </Text>


            <Text style={styles.centerText}>
              Conhecimento transforma.
              {"\n"}
              Educação constrói o futuro.
            </Text>


            <TouchableOpacity
              style={styles.startButton}
              onPress={() => setScreen("school")}
            >
              <Text style={styles.startButtonText}>
                ACESSAR SISTEMA
              </Text>
            </TouchableOpacity>


            <View style={styles.footer}>
              <Text style={styles.footerText}>
                Sistema de Gestão Escolar
              </Text>


              <Text style={styles.footerStars}>
                • • •
              </Text>
            </View>
          </View>
        </ScrollView>
      </SafeAreaView>
    );
  }


  /*
   * TELA PRINCIPAL DA ESCOLA
   */
  if (screen === "school") {
    return (
      <SafeAreaView style={styles.container}>
        <ScrollView
          contentContainerStyle={styles.schoolPage}
          showsVerticalScrollIndicator={false}
        >
          <TouchableOpacity
            style={styles.backButton}
            onPress={goBack}
          >
            <Text style={styles.backText}>
              ← Voltar
            </Text>
          </TouchableOpacity>


          <View
            style={[
              styles.schoolLogoContainer,
              { backgroundColor: escola.color },
            ]}
          >
            <Image
              source={escola.image}
              style={styles.schoolLogo}
              resizeMode="contain"
            />
          </View>


          <Text style={styles.pageSmall}>
            AMBIENTE ESCOLAR
          </Text>


          <Text style={styles.pageTitle}>
            {escola.name}
          </Text>


          <Text style={styles.pageDescription}>
            Educação • Conhecimento • Futuro
          </Text>


          <TouchableOpacity
            style={[
              styles.schoolCard,
              { borderColor: escola.color },
            ]}
            onPress={() => setScreen("login")}
            activeOpacity={0.85}
          >
            <View
              style={[
                styles.schoolCardBottom,
                { backgroundColor: escola.color },
              ]}
            >
              <Text style={styles.schoolCardTitle}>
                ENTRAR NO SISTEMA
              </Text>


              <Text style={styles.schoolCardSubtitle}>
                Acesse o ambiente escolar
              </Text>


              <View style={styles.cardArrow}>
                <Text style={styles.arrowText}>
                  →
                </Text>
              </View>
            </View>
          </TouchableOpacity>
        </ScrollView>
      </SafeAreaView>
    );
  }


  /*
   * LOGIN
   */
  if (screen === "login") {
    return (
      <SafeAreaView style={styles.container}>
        <ScrollView
          contentContainerStyle={styles.loginPage}
          showsVerticalScrollIndicator={false}
        >
          <TouchableOpacity
            style={styles.backButton}
            onPress={goBack}
          >
            <Text style={styles.backText}>
              ← Voltar
            </Text>
          </TouchableOpacity>


          <View
            style={[
              styles.selectedSchoolImage,
              {
                borderColor: escola.color,
                backgroundColor: escola.color,
              },
            ]}
          >
            <Image
              source={escola.image}
              style={styles.selectedImage}
              resizeMode="contain"
            />
          </View>


          <Text
            style={[
              styles.selectedSchoolName,
              { color: escola.color },
            ]}
          >
            SISTEMA ESCOLAR
          </Text>


          <Text style={styles.loginTitle}>
            Olá, novamente!
          </Text>


          <Text style={styles.loginSubtitle}>
            Escolha abaixo o seu perfil para acessar o sistema.
          </Text>


          <View style={styles.profileList}>
            <ProfileButton
              title="Aluno"
              icon="🎓"
              color={escola.color}
              onPress={() => selectProfile("Aluno")}
            />


            <ProfileButton
              title="Responsável"
              icon="👨‍👩‍👧"
              color={escola.color}
              onPress={() => selectProfile("Responsável")}
            />


            <ProfileButton
              title="Professor"
              icon="👨‍🏫"
              color={escola.color}
              onPress={() => selectProfile("Professor")}
            />


            <ProfileButton
              title="Coordenação"
              icon="📋"
              color={escola.color}
              onPress={() => selectProfile("Coordenação")}
            />
          </View>
        </ScrollView>
      </SafeAreaView>
    );
  }


  /*
   * DASHBOARD
   */
  if (screen === "dashboard") {
    const menus = getMenus(profile);


    return (
      <SafeAreaView style={styles.container}>
        <ScrollView
          contentContainerStyle={styles.dashboard}
          showsVerticalScrollIndicator={false}
        >
          <TouchableOpacity
            style={styles.backButton}
            onPress={goBack}
          >
            <Text style={styles.backText}>
              ← Sair do perfil
            </Text>
          </TouchableOpacity>


          <View style={styles.dashboardHeader}>
            <View
              style={[
                styles.smallLogo,
                { backgroundColor: escola.color },
              ]}
            >
              <Image
                source={escola.image}
                style={styles.smallLogoImage}
                resizeMode="contain"
              />
            </View>


            <View>
              <Text style={styles.dashboardSchool}>
                SISTEMA ESCOLAR
              </Text>


              <Text style={styles.dashboardProfile}>
                {profile}
              </Text>
            </View>
          </View>


          <Text style={styles.dashboardTitle}>
            Bem-vindo ao seu ambiente
          </Text>


          <Text style={styles.dashboardSubtitle}>
            Acesse as informações disponíveis para o seu perfil.
          </Text>


          <View style={styles.menuList}>
            {menus.map((menu) => (
              <MenuButton
                key={menu.id}
                title={menu.title}
                subtitle={menu.subtitle}
                icon={menu.icon}
                color={escola.color}
                onPress={() => {
                  setSelectedMenu(menu);
                  setScreen("section");
                }}
              />
            ))}
          </View>
        </ScrollView>
      </SafeAreaView>
    );
  }


  /*
   * SEÇÕES
   */
  if (screen === "section" && selectedMenu) {
    return (
      <SectionScreen
        menu={selectedMenu}
        profile={profile}
        goBack={goBack}
      />
    );
  }


  return null;
}


/*
 * MENUS DE CADA PERFIL
 */
function getMenus(profile) {
  if (profile === "Aluno") {
    return [
      {
        id: "turmas",
        title: "Turmas",
        subtitle: "Veja suas turmas e horários",
        icon: "🏫",
        items: turmas,
      },
      {
        id: "cursos",
        title: "Cursos",
        subtitle: "Cursos disponíveis para você",
        icon: "📚",
        items: [
          "Ensino Fundamental",
          "Ensino Médio",
          "Cursos Complementares",
        ],
      },
      {
        id: "disciplinas",
        title: "Disciplinas",
        subtitle: "Acesse suas disciplinas",
        icon: "📖",
        items: disciplinas,
      },
    
      {
        id: "boletim",
        title: "Boletim",
        subtitle: "Consulte suas notas e desempenho",
        icon: "📊",
        items: [
          "1º Bimestre",
          "2º Bimestre",
          "3º Bimestre",
          "4º Bimestre",
          "Média Final",
        ],
      },
    ];
  }


  if (profile === "Professor") {
    return [
      {
        id: "turmas",
        title: "Turmas",
        subtitle: "Gerencie suas turmas",
        icon: "🏫",
        items: turmas,
      },
      {
        id: "boletins",
        title: "Boletins",
        subtitle: "Consulte os boletins dos alunos",
        icon: "📊",
        items: [
          "1º Ano",
          "2º Ano",
          "3º Ano",
          "4º Ano",
          "5º Ano",
          "6º Ano",
          "7º Ano",
        ],
      },
      {
        id: "cursos",
        title: "Cursos",
        subtitle: "Cursos que você ministra",
        icon: "📚",
        items: [
          "Ensino Fundamental",
          "Ensino Médio",
          "Cursos Complementares",
        ],
      },
      {
        id: "disciplinas",
        title: "Disciplinas",
        subtitle: "Gerencie suas disciplinas",
        icon: "📖",
        items: disciplinas,
      },
      {
        id: "avaliacoes",
        title: "Avaliações",
        subtitle: "Crie e acompanhe avaliações",
        icon: "✏️",
        items: [
          "Provas",
          "Trabalhos",
          "Atividades",
          "Exames Finais",
        ],
      },
    ];
  }


  if (profile === "Responsável") {
    return [
      {
        id: "matriculas",
        title: "Matrículas",
        subtitle: "Consulte as matrículas",
        icon: "📝",
        items: [
          "Matrícula atual",
          "Situação da matrícula",
          "Documentos",
        ],
      },
      {
        id: "turmas",
        title: "Turmas",
        subtitle: "Consulte a turma do estudante",
        icon: "🏫",
        items: turmas,
      },
      {
        id: "avaliacoes",
        title: "Avaliações",
        subtitle: "Acompanhe as avaliações",
        icon: "✏️",
        items: [
          "Provas",
          "Trabalhos",
          "Atividades",
          "Exames",
        ],
      },
      {
        id: "boletim",
        title: "Boletim",
        subtitle: "Acompanhe o desempenho escolar",
        icon: "📊",
        items: [
          "1º Bimestre",
          "2º Bimestre",
          "3º Bimestre",
          "4º Bimestre",
          "Média Final",
        ],
      },
    ];
  }


  /*
   * COORDENAÇÃO
   */
  if (profile === "Coordenação") {
    return [
      {
        id: "matriculas",
        title: "Matrículas",
        subtitle: "Gerencie todas as matrículas",
        icon: "📝",
        items: [
          "Novas matrículas",
          "Matrículas ativas",
          "Transferências",
          "Documentos",
        ],
      },
      {
        id: "turmas",
        title: "Turmas",
        subtitle: "Gerencie todas as turmas",
        icon: "🏫",
        items: turmas,
      },
      {
        id: "cursos",
        title: "Cursos",
        subtitle: "Gerencie os cursos",
        icon: "📚",
        items: [
          "Ensino Fundamental",
          "Ensino Médio",
          "Cursos Complementares",
        ],
      },
      {
        id: "disciplinas",
        title: "Disciplinas",
        subtitle: "Gerencie todas as disciplinas",
        icon: "📖",
        items: disciplinas,
      },
      {
        id: "avaliacoes",
        title: "Avaliações",
        subtitle: "Acompanhe todas as avaliações",
        icon: "✏️",
        items: [
          "Provas",
          "Trabalhos",
          "Atividades",
          "Exames Finais",
        ],
      },
      {
        id: "boletins",
        title: "Boletins",
        subtitle: "Acesse todos os boletins",
        icon: "📊",
        items: [
          "1º Ano",
          "2º Ano",
          "3º Ano",
          "4º Ano",
          "5º Ano",
          "6º Ano",
          "7º Ano",
        ],
      },
    ];
  }


  return [];
}


/*
 * BOTÃO DE PERFIL
 */
function ProfileButton({
  title,
  icon,
  color,
  onPress,
}) {
  return (
    <TouchableOpacity
      style={styles.profileButton}
      onPress={onPress}
      activeOpacity={0.8}
    >
      <View
        style={[
          styles.profileIcon,
          { backgroundColor: color },
        ]}
      >
        <Text style={styles.profileEmoji}>
          {icon}
        </Text>
      </View>


      <View style={styles.profileTexts}>
        <Text style={styles.profileSmall}>
          Sou
        </Text>


        <Text style={styles.profileTitle}>
          {title}
        </Text>
      </View>


      <View style={styles.profileArrow}>
        <Text style={styles.profileArrowText}>
          →
        </Text>
      </View>
    </TouchableOpacity>
  );
}


/*
 * BOTÃO DOS MENUS
 */
function MenuButton({
  title,
  subtitle,
  icon,
  color,
  onPress,
}) {
  return (
    <TouchableOpacity
      style={styles.menuButton}
      onPress={onPress}
      activeOpacity={0.85}
    >
      <View
        style={[
          styles.menuIcon,
          { backgroundColor: color },
        ]}
      >
        <Text style={styles.menuEmoji}>
          {icon}
        </Text>
      </View>


      <View style={styles.menuTexts}>
        <Text style={styles.menuTitle}>
          {title}
        </Text>


        <Text style={styles.menuSubtitle}>
          {subtitle}
        </Text>
      </View>


      <Text style={styles.menuArrow}>
        →
      </Text>
    </TouchableOpacity>
  );
}


/*
 * TELA DE CADA SEÇÃO
 */
function SectionScreen({
  menu,
  profile,
  goBack,
}) {
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView
        contentContainerStyle={styles.sectionPage}
        showsVerticalScrollIndicator={false}
      >
        <TouchableOpacity
          style={styles.backButton}
          onPress={goBack}
        >
          <Text style={styles.backText}>
            ← Voltar
          </Text>
        </TouchableOpacity>


        <Text style={styles.sectionProfile}>
          {profile} • SISTEMA ESCOLAR
        </Text>


        <Text style={styles.sectionTitle}>
          {menu.title}
        </Text>


        <Text style={styles.sectionSubtitle}>
          {menu.subtitle}
        </Text>


        <View style={styles.itemsList}>
          {menu.items.map((item, index) => (
            <TouchableOpacity
              key={index}
              style={styles.itemCard}
              activeOpacity={0.85}
            >
              <View
                style={[
                  styles.itemNumber,
                  { backgroundColor: escola.color },
                ]}
              >
                <Text style={styles.itemNumberText}>
                  {index + 1}
                </Text>
              </View>


              <Text style={styles.itemText}>
                {item}
              </Text>


              <Text style={styles.itemArrow}>
                →
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}


/*
 * ESTILOS
 */
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F1F5F9",
  },


  homePage: {
    padding: 20,
    alignItems: "center",
  },


  welcomeCard: {
    width: "100%",
    maxWidth: 800,
    backgroundColor: "#FFFFFF",
    padding: 35,
    paddingTop: 40,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: "#D8DEE8",
    alignItems: "center",
  },


  logoCircle: {
    width: 90,
    height: 90,
    borderRadius: 45,
    backgroundColor: "#2563EB",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 20,
  },


  logoImage: {
    width: 65,
    height: 65,
  },


  smallTop: {
    textAlign: "center",
    color: "#64748B",
    fontSize: 10,
    letterSpacing: 2,
    fontWeight: "700",
  },


  schoolTitle: {
    textAlign: "center",
    color: "#172033",
    fontSize: 38,
    fontWeight: "800",
    marginTop: 15,
  },


  schoolSubtitle: {
    textAlign: "center",
    color: "#64748B",
    fontSize: 14,
    marginTop: 7,
  },


  line: {
    width: "80%",
    height: 1,
    backgroundColor: "#CBD5E1",
    marginVertical: 25,
  },


  greeting: {
    alignSelf: "flex-start",
    color: "#172033",
    fontSize: 22,
    fontWeight: "700",
    marginBottom: 15,
  },


  welcomeText: {
    width: "100%",
    color: "#475569",
    fontSize: 16,
    lineHeight: 26,
    marginBottom: 15,
    textAlign: "justify",
  },


  separator: {
    width: "100%",
    height: 1,
    backgroundColor: "#CBD5E1",
    marginVertical: 20,
  },


  invitation: {
    textAlign: "center",
    color: "#172033",
    fontSize: 19,
    fontWeight: "800",
    letterSpacing: 1.5,
    marginBottom: 12,
  },


  centerText: {
    color: "#64748B",
    fontSize: 15,
    lineHeight: 24,
    textAlign: "center",
  },


  startButton: {
    marginTop: 30,
    paddingVertical: 16,
    paddingHorizontal: 30,
    borderRadius: 8,
    backgroundColor: "#2563EB",
  },


  startButtonText: {
    color: "#FFFFFF",
    fontSize: 13,
    fontWeight: "800",
    letterSpacing: 1,
  },


  footer: {
    marginTop: 35,
    alignItems: "center",
  },


  footerText: {
    color: "#64748B",
    fontSize: 13,
  },


  footerStars: {
    color: "#2563EB",
    marginTop: 8,
  },


  schoolPage: {
    width: "100%",
    paddingHorizontal: 20,
    paddingTop: 25,
    paddingBottom: 50,
    alignItems: "center",
  },


  backButton: {
    alignSelf: "flex-start",
    marginBottom: 20,
  },


  backText: {
    color: "#2563EB",
    fontSize: 15,
    fontWeight: "600",
  },


  schoolLogoContainer: {
    width: 150,
    height: 150,
    borderRadius: 75,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 10,
  },


  schoolLogo: {
    width: "75%",
    height: "75%",
  },


  pageSmall: {
    color: "#2563EB",
    fontSize: 11,
    letterSpacing: 2,
    textAlign: "center",
    marginTop: 20,
    fontWeight: "700",
  },


  pageTitle: {
    color: "#172033",
    fontSize: 36,
    fontWeight: "800",
    marginTop: 12,
    textAlign: "center",
  },


  pageDescription: {
    color: "#64748B",
    marginTop: 8,
    marginBottom: 30,
    fontSize: 16,
  },


  schoolCard: {
    width: "100%",
    maxWidth: 500,
    borderWidth: 2,
    borderRadius: 12,
    overflow: "hidden",
    marginBottom: 18,
    backgroundColor: "#FFFFFF",
  },


  schoolCardBottom: {
    minHeight: 110,
    padding: 20,
    position: "relative",
    justifyContent: "center",
  },


  schoolCardTitle: {
    color: "#FFFFFF",
    fontSize: 18,
    fontWeight: "800",
  },


  schoolCardSubtitle: {
    color: "#FFFFFF",
    opacity: 0.85,
    fontSize: 12,
    marginTop: 7,
  },


  cardArrow: {
    position: "absolute",
    right: 15,
    top: 35,
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: "rgba(255,255,255,0.2)",
    justifyContent: "center",
    alignItems: "center",
  },


  arrowText: {
    color: "#FFFFFF",
    fontSize: 20,
  },


  loginPage: {
    padding: 25,
    paddingBottom: 60,
    alignItems: "center",
  },


  selectedSchoolImage: {
    width: 120,
    height: 120,
    borderRadius: 60,
    borderWidth: 3,
    justifyContent: "center",
    alignItems: "center",
    overflow: "hidden",
  },


  selectedImage: {
    width: 95,
    height: 95,
  },


  selectedSchoolName: {
    marginTop: 12,
    fontSize: 15,
    fontWeight: "800",
    letterSpacing: 2,
  },


  loginTitle: {
    color: "#172033",
    fontSize: 30,
    fontWeight: "800",
    marginTop: 20,
  },


  loginSubtitle: {
    color: "#64748B",
    marginTop: 8,
    marginBottom: 25,
    textAlign: "center",
  },


  profileList: {
    width: "100%",
    maxWidth: 560,
  },


  profileButton: {
    minHeight: 82,
    backgroundColor: "#FFFFFF",
    borderRadius: 12,
    flexDirection: "row",
    alignItems: "center",
    padding: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: "#E2E8F0",
  },


  profileIcon: {
    width: 55,
    height: 55,
    borderRadius: 10,
    justifyContent: "center",
    alignItems: "center",
  },


  profileEmoji: {
    fontSize: 24,
  },


  profileTexts: {
    flex: 1,
    marginLeft: 15,
  },


  profileSmall: {
    color: "#94A3B8",
    fontSize: 13,
  },


  profileTitle: {
    color: "#172033",
    fontSize: 20,
    fontWeight: "700",
  },


  profileArrow: {
    width: 38,
    height: 38,
    borderRadius: 20,
    backgroundColor: "#F1F5F9",
    justifyContent: "center",
    alignItems: "center",
  },


  profileArrowText: {
    color: "#2563EB",
    fontSize: 20,
  },


  dashboard: {
    padding: 25,
    paddingBottom: 60,
  },


  dashboardHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 30,
  },


  smallLogo: {
    width: 65,
    height: 65,
    borderRadius: 33,
    justifyContent: "center",
    alignItems: "center",
    marginRight: 15,
  },


  smallLogoImage: {
    width: 52,
    height: 52,
  },


  dashboardSchool: {
    color: "#2563EB",
    fontSize: 13,
    fontWeight: "800",
    letterSpacing: 1.5,
  },


  dashboardProfile: {
    color: "#172033",
    fontSize: 22,
    fontWeight: "800",
    marginTop: 4,
  },


  dashboardTitle: {
    color: "#172033",
    fontSize: 30,
    fontWeight: "800",
  },


  dashboardSubtitle: {
    color: "#64748B",
    fontSize: 15,
    marginTop: 8,
    marginBottom: 25,
  },


  menuList: {
    width: "100%",
  },


  menuButton: {
    backgroundColor: "#FFFFFF",
    minHeight: 85,
    borderRadius: 12,
    padding: 12,
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 12,
    borderWidth: 1,
    borderColor: "#E2E8F0",
  },


  menuIcon: {
    width: 58,
    height: 58,
    borderRadius: 10,
    justifyContent: "center",
    alignItems: "center",
  },


  menuEmoji: {
    fontSize: 26,
  },


  menuTexts: {
    flex: 1,
    marginLeft: 15,
  },


  menuTitle: {
    color: "#172033",
    fontSize: 19,
    fontWeight: "800",
  },


  menuSubtitle: {
    color: "#64748B",
    fontSize: 12,
    marginTop: 4,
  },


  menuArrow: {
    color: "#2563EB",
    fontSize: 24,
    marginRight: 8,
  },


  sectionPage: {
    padding: 25,
    paddingBottom: 60,
  },


  sectionProfile: {
    color: "#2563EB",
    fontSize: 12,
    fontWeight: "800",
    letterSpacing: 1.5,
    marginTop: 10,
  },


  sectionTitle: {
    color: "#172033",
    fontSize: 34,
    fontWeight: "800",
    marginTop: 10,
  },


  sectionSubtitle: {
    color: "#64748B",
    fontSize: 15,
    marginTop: 7,
    marginBottom: 25,
  },


  itemsList: {
    width: "100%",
  },


  itemCard: {
    minHeight: 68,
    backgroundColor: "#FFFFFF",
    borderRadius: 10,
    marginBottom: 10,
    padding: 10,
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#E2E8F0",
  },


  itemNumber: {
    width: 42,
    height: 42,
    borderRadius: 21,
    justifyContent: "center",
    alignItems: "center",
  },


  itemNumberText: {
    color: "#FFFFFF",
    fontWeight: "800",
    fontSize: 15,
  },


  itemText: {
    flex: 1,
    color: "#172033",
    fontSize: 16,
    fontWeight: "600",
    marginLeft: 13,
  },


  itemArrow: {
    color: "#2563EB",
    fontSize: 20,
    marginRight: 8,
  },
});
